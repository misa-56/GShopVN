<div id="slide" class="carousel slide m1-auto" data-ride="carousel" data-interval="3000">
    <ul class="carousel-indicators">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $slide_no = $slider->id;
                $slide_no = $slide_no + 1;
            ?>
            <li data-target="#slide" data-slide-to="$slide_no"
                class=" 
          <?php if($slider->id == '1'): ?> active <?php endif; ?>"></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="carousel-inner">


        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item
          <?php if($slider->id == '1'): ?> active <?php endif; ?>
          ">
                <img class="rounded-right img-fluid" src="<?php echo e($slider->thumb); ?>" alt="<?php echo e($slider->name); ?>" width="1100"
                    height="500" />
                <div class="carousel-caption">
                    <a class="text-white" href="<?php echo e($slider->url); ?>">
                        <h4><?php echo e($slider->name); ?></h4>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    <a class="carousel-control-prev" href="#slide" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#slide" data-slide="next">
        <span class="carousel-control-next-icon"></span>
    </a>
</div>
<?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/slider.blade.php ENDPATH**/ ?>