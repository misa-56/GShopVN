<?php
      $searchCount = count($products);                 
?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class=" col-12 my-3 my-md-5">
        <h2>Kết quả tìm kiếm: tìm thấy <?php echo e($searchCount); ?> sản phẩm</h2>
        <a href="/" class="text-secondary">Trang chủ</a><span> / <a href="/san-pham" class="text-secondary">Shop</a> / <?php echo e($title); ?></span>
      </div>
      <div class="col-md-8 order-md-2 col-lg-9">
        <div class="container-fluid">
            
          <?php echo $__env->make('products.sort', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
          <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo $__env->make('products.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($searchCount == 0): ?>
                <p>Không tìm thấy sản phẩm bạn muốn, xin hãy thử từ khóa tìm kiếm khác</p>
            <?php endif; ?>
          </div>
          
          
        </div>
      </div>

        <?php echo $__env->make('products.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/search.blade.php ENDPATH**/ ?>