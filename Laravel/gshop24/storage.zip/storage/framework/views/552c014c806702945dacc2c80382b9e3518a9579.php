<div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="container">



                <div class="modal-header text-center">

                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#home">Đăng nhập</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link dangky" data-toggle="tab" href="#menu1">Đăng ký</a>
                        </li>
                    </ul>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="tab-content">
                    <div id="home" class="modal-body mx-md-3 tab-pane active">
                        
                        <?php if(session('error')): ?>
                            <p class="text-danger"> <?php echo e(session('error')); ?> </p>
                        <?php endif; ?>
                        <?php if(session('login-message')): ?>
                            <p class="text-danger"> <?php echo e(session('login-message')); ?> </p>
                        <?php endif; ?>

                        <form id="login" action="<?php echo e(url('/login')); ?>" method="post">
                            <div class="form-group <?php echo e($errors->account->has('login-email') ? ' has-error' : ''); ?>">
                                <input type="text" name="login-email" class="form-control" placeholder="Nhập Email"
                                    value="" />
                                <?php if($errors->account->has('login-email')): ?>
                                    <span class="text-danger"><?php echo e($errors->account->first('login-email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?php echo e($errors->account->has('login-password') ? ' has-error' : ''); ?>">
                                <input type="password" name="login-password" class="form-control" placeholder="Mật Khẩu"
                                    value="" />
                                <?php if($errors->account->has('login-password')): ?>
                                    <span class="text-danger"><?php echo e($errors->account->first('login-password')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="d-flex justify-content-between">
                                <div class="icheck-primary">
                                    <input type="checkbox" name="remember" id="remember">
                                    <label for="remember">
                                        Ghi nhớ mật khẩu
                                    </label>
                                </div>
                                <div class="form-group">
                                    <a href="<?php echo e(url('/quen-mat-khau')); ?>" class="ForgetPwd">Quên Mật Khẩu?</a>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btnSubmit btn btn-info rounded-pill w-100"
                                    value="Đăng Nhập" />
                            </div>
                            <p class="font-small dark-grey-text text-right d-flex justify-content-center mb-3 pt-2">
                                hoặc Đăng nhập với:</p>
                            <div class="row my-3 d-flex justify-content-center">
                                <!--Facebook-->
                                <a href="<?php echo e(route('facebook.login')); ?>"
                                    class="btn btn-white btn-rounded mr-3 z-depth-1a waves-effect waves-light shadow rounded-pill w-25"><i
                                        class="text-info fab fa-facebook-f text-center"></i></a>
                                <!--Google +-->
                                <a href="<?php echo e(route('google.login')); ?>"
                                    class="btn btn-white btn-rounded z-depth-1a waves-effect waves-light shadow rounded-pill w-25"><i
                                        class="text-info fab fa-google"></i></a>
                            </div>
                            <?php echo csrf_field(); ?>
                        </form>

                    </div>

                    
                    <div id="menu1" class="modal-body mx-md-3 tab-pane fade "><br>
                        <?php if(session('message')): ?>
                            <p class="text-danger"> <?php echo e(session('message')); ?> </p>
                        <?php endif; ?>
                        <form id="register" action="<?php echo e(url('/register')); ?>" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Họ & Tên" value=""
                                    name="name" />
                                <?php if($errors->account->has('name')): ?>
                                    <span class="text-danger"><?php echo e($errors->account->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Số Điện Thoại" value=""
                                    name="phone" />
                                <?php if($errors->account->has('phone')): ?>
                                    <span class="text-danger"><?php echo e($errors->account->first('phone')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Nhập Email" value=""
                                    name="email" />
                                <?php if($errors->account->has('email')): ?>
                                    <span class="text-danger"><?php echo e($errors->account->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" placeholder="Mật Khẩu" value=""
                                    name="password" autocomplete="off" />
                                <?php if($errors->account->has('password')): ?>
                                    <span class="text-danger"><?php echo e($errors->account->first('password')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btnSubmit btn rounded-pill btn-info w-100"
                                    value="Tạo Tài Khoản" />
                            </div>
                            <?php echo csrf_field(); ?>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/login.blade.php ENDPATH**/ ?>