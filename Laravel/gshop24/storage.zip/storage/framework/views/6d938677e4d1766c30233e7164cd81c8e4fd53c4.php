

<?php $__env->startSection('content'); ?>
    <!-- ------------------------------------ -->
<section id="content" class="container my-2 my-lg-3">
    <div class="mainBody">
        
        <div>
            <?php echo $page->content; ?>

        </div>
    </div>
    
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/page.blade.php ENDPATH**/ ?>