<?php $__env->startSection('content'); ?>
    <div class="customer mt-3">
        <ul>
            <li>Tên khách hàng: <strong><?php echo e($customer->name); ?></strong></li>
            <li>Số điện thoại: <strong><?php echo e($customer->phone); ?></strong></li>
            <li>Email: <strong><?php echo e($customer->email); ?></strong></li>
            <li>Ghi chú: <strong><?php echo e($customer->content); ?></strong></li>
            <li>Phương thức thanh toán: <strong><?php echo e($customer->payment_method); ?></strong></li>
        </ul>
    </div>

    <div class="carts">
        <?php $total = 0; ?>
        <table class="table">
            <tbody>
            <tr class="table_head">
                <th class="column-1">IMG</th>
                <th class="column-2">Product</th>
                <th class="column-3">Price</th>
                <th class="column-4">Quantity</th>
                <th class="column-5">Total</th>
            </tr>

            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $price = $cart->price * $cart->pty;
                    $total += $price;
                ?>
                <tr>
                    <td class="column-1">
                        <div class="how-itemcart1">
                            <img src="<?php echo e($cart->product->thumb); ?>" alt="IMG" style="width: 100px">
                        </div>
                    </td>
                    <td class="column-2"><p><?php echo e($cart->product->name); ?></p>
                        <?php if($cart->account_email !== ""): ?>
                            <small>Email/User: <?php echo e($cart->account_email); ?></small>
                            <?php if($cart->account_password !== ""): ?>
                            <small><br>Password: <?php echo e($cart->account_password); ?></small>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td class="column-3"><?php echo e(number_format($cart->price, 0, '', '.')); ?></td>
                    <td class="column-4"><?php echo e($cart->pty); ?></td>
                    <td class="column-5"><?php echo e(number_format($price, 0, '', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="4" class="text-right">Tổng Tiền</td>
                    <td><?php echo e(number_format($total, 0, '', '.')); ?></td>
                </tr>
            </tbody>
        </table>
        <div class="p-3">
            
                
                <form action="" method="POST">
                    <h4 class="text-success"><strong>STATUS:</strong> Khách hàng đã thanh toán đơn hàng này?</h4>
                    
                    <div class="custom-control custom-radio">
                        
                        <label for="paid" class="">Đã thanh toán</label>
                        <input type="checkbox" id="paid" name="paid"
                            <?php echo e($customer->status == 1 || $customer->status == 2  ? ' checked=""' : ''); ?>

                            >
                    </div>
                    

                    <div>
                            <label>Đã gửi hàng xong?</label>
                            <input type="checkbox" name="delivered"
                            <?php echo e($customer->status == 2 ? ' checked=""' : ''); ?>

                            >
                            
                    </div>
                    
                    <?php if(Session::has('error')): ?>
                                <div class="text-danger">
                                    <?php echo e(Session::get('error')); ?>

                                </div>
                            <?php endif; ?>
                    
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Cập Nhật Tình Trạng Đơn Hàng</button>
                    </div> 
                    <?php echo csrf_field(); ?>
                </form>
            
        </div>
        
        
    </div>
    
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/admin/carts/detail.blade.php ENDPATH**/ ?>