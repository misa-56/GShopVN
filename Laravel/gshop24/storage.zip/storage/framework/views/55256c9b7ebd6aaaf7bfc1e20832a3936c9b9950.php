<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="icon" type="image" href="/template/images/icons/logo_2.png"/>
</head>

<body class="d-flex flex-column min-vh-100">
    <!--class="animsition" -->

<!-- Header -->

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Cart -->


<?php echo $__env->yieldContent('content'); ?>


<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/main.blade.php ENDPATH**/ ?>