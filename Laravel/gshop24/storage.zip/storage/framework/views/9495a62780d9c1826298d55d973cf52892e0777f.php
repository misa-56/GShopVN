

<?php $__env->startSection('content'); ?>
    
    <section class="container">
        <div class="row my-3">
            <div class="col-12 col-md-3">
                <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <a class="nav-link active bg-info"  href="/profile" >
                      <i class="user-icon fas fa-user border-0 mr-3" aria-hidden="true"></i>Tài khoản</a>
                    <a class="nav-link text-info"  href="/my-order" >
                      <i class="fa-solid fa-box mr-3"></i>Đơn hàng của tôi</a>
                    <a class="nav-link text-info" href="<?php echo e(url('profile_logout')); ?>">Thoát</a>
                </div>
            </div>
            <div class="col-12 col-md-9">
                <div class="tab-content bg-white p-4" id="v-pills-tabContent">
                    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                        <h3>Thông tin cá nhân</h3>
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                              <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('ok')): ?>
                            <div class="alert alert-success">
                              <?php echo e(Session::get('ok')); ?>

                            </div>
                        <?php endif; ?>
                        
                      <form class="" action="<?php echo e(URL::to('/profile/update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            
                            <div class="form-group">
                              <label for="email">Địa chỉ email</label>
                              <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
                              <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                              <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="name">Tên hiển thị&nbsp;<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>">
                                <?php if($errors->has('name')): ?>
                                  <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                              </div>
   
                              <div class="form-group">
                                <label for="phone">Số điện thoại&nbsp;<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($user->phone); ?>">
                                <?php if($errors->has('phone')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                <?php endif; ?>
                              </div>
                        
                              <div class="form-group">
                                <legend>Thay đổi mật khẩu</legend>
                                <?php if(Session::has('warning')): ?>
                                    <div class="alert alert-danger">
                                      <?php echo e(Session::get('warning')); ?>

                                    </div>
                                <?php endif; ?>
                                
                                <label for="password_current">Mật khẩu hiện tại</label>
                                <input type="password" class="form-control" id="name" name="old_password">
                                <?php if($errors->has('old_password')): ?>
                                  <span class="text-danger"><?php echo e($errors->first('old_password')); ?></span>
                                <?php endif; ?>
                                
                              </div>

                              <div class="form-group">
                                <label for="password_1">Mật khẩu mới</label>
                                <input type="password" class="form-control" id="password_1" name="password_1" autocomplete="off">
                                <?php if($errors->has('password_1')): ?>
                                  <span class="text-danger"><?php echo e($errors->first('password_1')); ?></span>
                                <?php endif; ?>
                              </div>

                              <div class="form-group">
                                <label for="password_2">Xác nhận mật khẩu mới</label>
                                <input type="password" class="form-control" id=
                                "password_2" name="password_2" autocomplete="off">
                                <?php if($errors->has('password_2')): ?>
                                  <span class="text-danger"><?php echo e($errors->first('password_2')); ?></span>
                                <?php endif; ?>
                              </div>

                            <p>
                                <input type="hidden" id="save-account-details-nonce" name="save-account-details-nonce" value="8c0a4033a7"><input type="hidden" name="_wp_http_referer" value="/my-account/edit-account/">		
                                <button type="submit" class="btn bg-info text-white" name="save_account_details" value="Lưu">Lưu</button>
                                <input type="hidden" name="action" value="save_account_details">
                            </p>
                        
                        </form>
                    </div>
                    <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                      
                    </div>
                    
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views//profile/profile.blade.php ENDPATH**/ ?>