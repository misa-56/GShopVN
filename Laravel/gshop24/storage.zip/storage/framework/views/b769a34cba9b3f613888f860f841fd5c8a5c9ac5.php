<div class="row sorting mb-3 mt-3">
        <div class="col-12 d-flex justify-content-between">
          
          
          <div class="dropdown float-md-left">
            <?php echo $products->links(); ?>

          </div>
          <div>
          <a class="btn btn-info border" href="#"><i class="fas fa-arrow-up"></i></a>
          </div>
        </div>
      </div><?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/products/bottom.blade.php ENDPATH**/ ?>