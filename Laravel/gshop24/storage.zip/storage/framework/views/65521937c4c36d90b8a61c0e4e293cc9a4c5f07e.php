<div class="col-6 col-md-4 col-lg-3 p-2">

    <div class="border rounded text-center p-3 bg-white h-100">
        <a class="text-decoration-none"
            href="/san-pham/<?php echo e($product->id); ?>-<?php echo e(Str::slug($product->name, '-')); ?>.html"><img class="w-100 rounded mb-3"
                src="<?php echo e($product->thumb); ?>" alt="<?php echo e($product->name); ?>">
            <h5><?php echo e($product->name); ?></h5>
        </a>
        <p class="text-danger">
            <?php if($product->price_sale != null): ?>
                <?php echo \App\Helpers\Helper::price($product->price, $product->price_sale); ?><sup>đ</sup>
                <small class="text-muted"><s><?php echo \App\Helpers\Helper::price($product->price); ?><sup>đ</sup></s></small>
                <span class="bg-danger rounded text-light p-1">
                    <?php
                        $price = \App\Helpers\Helper::price($product->price);
                        $sale = \App\Helpers\Helper::price($product->price_sale);
                        $discount = floor(((float) $sale / (float) $price) * 100) - 100;
                    ?>
                    <?php echo e($discount); ?> %
                </span>
            <?php else: ?>
                <?php echo \App\Helpers\Helper::price($product->price, $product->price_sale); ?><sup>đ</sup>
            <?php endif; ?>
        </p>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/home/list.blade.php ENDPATH**/ ?>