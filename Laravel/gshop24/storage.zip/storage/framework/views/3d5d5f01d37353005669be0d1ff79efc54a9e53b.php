<div class="row ">
    <div class="col-12">
      <div class="dropdown text-md-left text-center float-md-right mb-3 mt-3 mt-md-0 mb-md-0">
        
        <a class="btn btn-light dropdown-toggle border" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Mặc định <span class="caret"></span></a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown" x-placement="bottom-start" style="position: absolute; transform: translate3d(71px, 48px, 0px); top: 0px; left: 0px; will-change: transform;">
          
          <a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['price' => 'asc'])); ?>">Giá từ thấp đến cao</a>
          <a class="dropdown-item" href="<?php echo e(request()->fullUrlWithQuery(['price' => 'desc'])); ?>">Giá từ cao đến thấp</a>
          
        </div>
      </div>
      
    </div>
  </div><?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/products/sort.blade.php ENDPATH**/ ?>