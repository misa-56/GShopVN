



<?php $__env->startSection('content'); ?>
<?php $total1 = 0; ?>
<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $price = $cart->price * $cart->pty;
        $total1 += $price;
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <section class="container">
        <div class="row my-5">
            
            
            <?php if($customer->payment_method == 'momo'): ?>
            
            <div class="col-12 text-center col-md-8">
                
                <table class="table table-bordered table-info">
                    <thead>
                      <tr>
                        <th  colspan="2">Thông tin chuyển khoản</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Người nhận</td>
                        <td>Hoàng Thị Triều Giang</td>
                      </tr>

                      <tr>
                        <td>Số điện thoại</td>
                        <td>0965324305</td>
                      </tr>

                      <tr>
                        <td>Số tiền</td>
                        <td class="text-danger"><sup>₫</sup><strong><?php echo e(number_format($total1, 0, '', '.')); ?></strong></td>
                      </tr>

                      <tr>
                        <td>Nội dung chuyển khoản</td>
                        <td><strong class="text-danger"><?php echo e(str_pad($customer->id , 5, "0", STR_PAD_LEFT)); ?></strong></td>
                      </tr>
                      
                    </tbody>
                  </table>

                
                
                <h4 class="text-primary">Quét mã dưới đây để thanh toán</h4>
                <img 
                class="rounded m-3" 
                src="/template/images/checkout/momo_qr.png" 
                alt="momo_checkout" 
                width="300px"
                height="300px">

                
                <p id="footer_scan">
                    <i class="fa-solid fa-qrcode"></i>
                    Sử dụng App <b>MoMo</b> để quét mã.
                    <br>
                    
                    <img width="38" class="" src="/template/images/loading.gif" alt="loading"> 
                    <br><button class="btn btn-info" onclick="paid()">Tôi đã thanh toán xong</button>
                    <p id="paid" class="bg-warning font-weight-bold"></p>
                    <br><strong>Nếu chưa thanh toán, đơn hàng sẽ tự động hủy sau 24h</strong>
                </p>

                
                
            </div>
            <?php else: ?>
            
            <div class="col-12 text-center col-md-8">

                <table class="table table-bordered table-info">
                    <thead>
                      <tr>
                        <th  colspan="2">Thông tin chuyển khoản</th>
                      </tr>
                    </thead>
                    <tbody>

                      <tr>
                        <td>Tên tài khoản</td>
                        <td>HOANG THI TRIEU GIANG</td>
                      </tr>
                      <tr>
                        <td>Số tài khoản</td>
                        <td>3070199747777</td>
                      </tr>
                      <tr>
                        <td>Ngân hàng</td>
                        <td>Quân Đội MB-Bank</td>
                      </tr>
                      <tr>
                        <td>Số tiền</td>
                        <td class="text-danger"><sup>₫</sup><strong><?php echo e(number_format($total1, 0, '', '.')); ?></strong></td>
                      </tr>
                      <tr>
                        <td>Nội dung chuyển khoản</td>
                        <td><strong class="text-danger"><?php echo e(str_pad($customer->id , 5, "0", STR_PAD_LEFT)); ?></strong></td>
                      </tr>

                    </tbody>
                  </table>

                <h4 class="text-primary">
                    <i class="fa-solid fa-qrcode"></i>
                    Mã QR chuyển khoản</h4>
                <img 
                class="rounded m-3" 
                src="/template/images/checkout/banking_qr.jpg" 
                alt="momo_checkout" 
                width="300px"
                height="300px">

                <p id="footer_scan">

                    <img width="38" class="" src="/template/images/loading.gif" alt="loading"> 
                    <br><button class="btn btn-info" onclick="paid()">Tôi đã thanh toán xong</button>
                    <p id="paid" class="bg-warning font-weight-bold"></p>
                    <br><strong>Nếu chưa thanh toán, đơn hàng sẽ tự động hủy sau 24h</strong>
                </p>

            </div>
            <?php endif; ?>

            

            
            
            <div class="col-12 col-md-4 ">
                
                    
                <div class="p-3 border rounded bg-white" >
                    <p class="text-success"><strong>Đơn hàng đã được tiếp nhận</strong></p>
                    
                    <hr>
                    <ul class="list-unstyled m-0">
                        <li>Mã đơn hàng: <strong><?php echo e(str_pad($customer->id , 5, "0", STR_PAD_LEFT)); ?></strong></li>
                        <li>Ngày tạo: <?php echo e($customer->created_at); ?><strong></strong></li>
                        <li>Tổng cộng: <sup>₫</sup><strong><?php echo e(number_format($total1, 0, '', '.')); ?></strong></li>
                        <li>Phương thức thanh toán: 
                            <?php if($customer->payment_method == 'momo'): ?>
                            <span>MoMo</span>
                            <?php else: ?>
                            <span>Chuyển khoản ngân hàng</span>
                            <?php endif; ?></li>
                        
                    </ul>
                    
                    
                </div>
                <div class="bg-white p-3 my-3 border rounded">
                    <p><?php echo e($customer->name); ?></p>
                    <p class="text-secondary"><?php echo e($customer->email); ?></p>
                    <p class="text-secondary"><?php echo e($customer->phone); ?></p>
                </div>
            </div>

            
        </div>
        
        

      <div class="carts">
        <h3 class="">Chi tiết đơn hàng</h3>
          <?php $total = 0; ?>
          <table class="table">
              <tbody>
              <tr class="table_head">
                  <th class="column-1"></th>
                  <th class="column-2">Sản phẩm</th>
                  <th class="column-3">Giá</th>
                  <th class="column-4">Số lượng</th>
                  <th class="column-5">Tổng</th>
              </tr>

              <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                      $price = $cart->price * $cart->pty;
                      $total += $price;
                  ?>
                  <tr>
                      <td class="column-1">
                          <div class="how-itemcart1">
                              <img src="<?php echo e($cart->product->thumb); ?>" alt="IMG" style="width: 100px">
                          </div>
                      </td>
                      <td class="column-2"><p><?php echo e($cart->product->name); ?></p>
                        <?php if($cart->account_email !== ""): ?>
                            <small>Email/User: <?php echo e($cart->account_email); ?></small>
                            <?php if($cart->account_password !== ""): ?>
                            <small><br>Password: <?php echo e($cart->account_password); ?></small>
                            <?php endif; ?>
                        <?php endif; ?>
                      
                      </td>
                      <td class="column-3"><sup>₫</sup><?php echo e(number_format($cart->price, 0, '', '.')); ?></td>
                      <td class="column-4"><?php echo e($cart->pty); ?></td>
                      <td class="column-5"><sup>₫</sup><?php echo e(number_format($price, 0, '', '.')); ?></td>
                  </tr>
                  <tr>
                    
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td colspan="5">
                    Ghi chú đơn hàng: <?php echo e($customer->content); ?>

                </td>
              </tr>

                  <tr>
                      <td colspan="4" class="text-right">Tổng Tiền</td>
                      <td class="text-danger"><sup>₫</sup><?php echo e(number_format($total, 0, '', '.')); ?></td>
                  </tr>
              </tbody>
          </table>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<script>
  function paid() {
    document.getElementById("paid").innerHTML = "Đã ghi nhận đơn hàng, GShop sẽ phản hồi sớm nhất!";
  }
  </script>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/carts/checkout.blade.php ENDPATH**/ ?>