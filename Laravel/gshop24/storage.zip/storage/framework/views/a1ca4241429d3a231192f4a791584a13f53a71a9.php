<?php $__env->startSection('head'); ?>
    <script src="/ckeditor/ckeditor.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="" method="POST">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="menu">Tên Sản Phẩm</label>
                        <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control"
                               placeholder="Nhập tên sản phẩm">
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Danh Mục</label>
                        <select class="form-control" name="menu_id">
                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($menu->id); ?>" <?php echo e($product->menu_id == $menu->id ? 'selected' : ''); ?>>
                                    <?php echo e($menu->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="menu">Giá Gốc</label>
                        <input type="number" name="price" value="<?php echo e($product->price); ?>"  class="form-control" >
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="menu">Giá Giảm</label>
                        <input type="number" name="price_sale" value="<?php echo e($product->price_sale); ?>"  class="form-control" >
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Mô Tả </label>
                <textarea name="description" class="form-control"><?php echo e($product->description); ?></textarea>
            </div>

            <div class="form-group">
                <label>Mô Tả Chi Tiết</label>
                <textarea name="content" id="content" class="form-control"><?php echo e($product->content); ?></textarea>
            </div>

            <div class="form-group">
                <label for="menu">Ảnh Sản Phẩm</label>
                <input type="file"  class="form-control" id="upload">
                <div id="image_show">
                    <a href="<?php echo e($product->thumb); ?>" target="_blank">
                        <img src="<?php echo e($product->thumb); ?>" width="100px">
                    </a>
                </div>
                <input type="hidden" name="thumb" value="<?php echo e($product->thumb); ?>" id="thumb">
            </div>

            
            <div class="form-group">
                <label>Kích Hoạt</label>
                <div class="custom-control custom-radio">
                    <input class="custom-control-input" value="1" type="radio" id="active" name="active"
                        <?php echo e($product->active == 1 ? ' checked=""' : ''); ?>>
                    <label for="active" class="custom-control-label">Có</label>
                </div>
                <div class="custom-control custom-radio">
                    <input class="custom-control-input" value="0" type="radio" id="no_active" name="active"
                        <?php echo e($product->active == 0 ? ' checked=""' : ''); ?>>
                    <label for="no_active" class="custom-control-label">Không</label>
                </div>
            </div>

            
            <div class="form-group">
                <label>Đặt làm sản phẩm nổi bật</label>
                <div class="custom-control custom-radio">
                    <input class="custom-control-input" value="1" type="radio" id="featured" name="featured"
                        <?php echo e($product->featured == 1 ? ' checked=""' : ''); ?>>
                    <label for="featured" class="custom-control-label">Có</label>
                </div>
                <div class="custom-control custom-radio">
                    <input class="custom-control-input" value="0" type="radio" id="no_featured" name="featured"
                        <?php echo e($product->featured == 0 ? ' checked=""' : ''); ?>>
                    <label for="no_featured" class="custom-control-label">Không</label>
                </div>
            </div>

            
            <div class="form-group">
                <label>Stock</label>
                <div class="custom-control custom-radio">
                    <input class="custom-control-input" value="1" type="radio" id="stock" name="stock"
                        <?php echo e($product->stock == 1 ? ' checked=""' : ''); ?>>
                    <label for="stock" class="custom-control-label">Còn hàng</label>
                </div>
                <div class="custom-control custom-radio">
                    <input class="custom-control-input" value="0" type="radio" id="no_stock" name="stock"
                        <?php echo e($product->stock == 0 ? ' checked=""' : ''); ?>>
                    <label for="no_stock" class="custom-control-label">Hết hàng</label>
                </div>
            </div>
            
            
            <div class="form-group">
                <label>Yêu cầu Email</label>
                <div class="custom-control custom-radio">
                    <input class="custom-control-input" value="1" type="radio" id="account_email" name="account_email"
                        <?php echo e($product->account_email == 1 ? ' checked=""' : ''); ?>>
                    <label for="account_email" class="custom-control-label">Yêu cầu Email</label>
                </div>
                <div class="custom-control custom-radio">
                    <input class="custom-control-input" value="0" type="radio" id="no_email" name="account_email"
                        <?php echo e($product->account_email == 0 ? ' checked=""' : ''); ?>>
                    <label for="no_email" class="custom-control-label">Không yêu cầu Email</label>
                </div>
            </div>
            <div class="form-group">
                <label>Yêu cầu Password</label>
                <div class="custom-control custom-radio">
                    
                    <input class="custom-control-input" value="1" type="radio" id="account_password" name="account_password"
                    <?php echo e($product->account_password == 1 ? ' checked=""' : ''); ?>>
                    <label for="account_password" class="custom-control-label">Yêu cầu Password </label>
                </div>
                <div class="custom-control custom-radio">
                    <input class="custom-control-input" value="0" type="radio" id="no_password" name="account_password"
                    <?php echo e($product->account_password == 0 ? ' checked=""' : ''); ?>

                        >
                    <label for="no_password" class="custom-control-label">Không yêu cầu Password</label>
                </div>
            </div>

            <div class="form-group">
                <label>Mã hàng</label>
                <div class="">
                    
                    <input class="" value="<?php echo e($product->product_code); ?>" type="text" id="product_code" name="product_code" placeholder="Nhập mã hàng">
                    
                </div>
                
            </div>
            <div class="form-group">
                <label>Thời hạn</label>
                <div class="">
                    
                    <input class="" value="<?php echo e($product->term); ?>" type="text" id="term" name="term" placeholder="Nhập thời hạn nếu có">
                    
                </div>
                
            </div>



        </div>

        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Cập Nhật Sản Phẩm</button>
        </div>
        <?php echo csrf_field(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        CKEDITOR.replace('content');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GShop\Laravel\gshop24\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>